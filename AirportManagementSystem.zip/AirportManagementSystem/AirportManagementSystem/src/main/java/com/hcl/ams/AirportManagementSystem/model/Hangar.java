package com.hcl.ams.AirportManagementSystem.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component("hangar")
@Entity
@Table(name = "hangars")
public class Hangar {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "HANGAR_ID")
	private int hangarId;

	@Column(name = "HANGAR_LOCATION", length = 10, unique = true)
	private String hangarLocation;

	private int planeId;

	public Hangar() {
		super();
	}

	public Hangar(int hangarId, String hangarLocation, int planeId) {
		super();
		this.hangarId = hangarId;
		this.hangarLocation = hangarLocation;
		this.planeId = planeId;
	}

	public int getHangarId() {
		return hangarId;
	}

	public void setHangarId(int hangarId) {
		this.hangarId = hangarId;
	}

	public String getHangarLocation() {
		return hangarLocation;
	}

	public void setHangarLocation(String hangarLocation) {
		this.hangarLocation = hangarLocation;
	}

	public int getPlaneId() {
		return planeId;
	}

	public void setPlaneId(int planeId) {
		this.planeId = planeId;
	}

}
