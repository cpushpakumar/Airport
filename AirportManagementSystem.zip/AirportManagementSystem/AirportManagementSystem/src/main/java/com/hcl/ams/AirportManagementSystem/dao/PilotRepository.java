package com.hcl.ams.AirportManagementSystem.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.ams.AirportManagementSystem.model.Pilot;

public interface PilotRepository extends JpaRepository<Pilot, Long> {

}
