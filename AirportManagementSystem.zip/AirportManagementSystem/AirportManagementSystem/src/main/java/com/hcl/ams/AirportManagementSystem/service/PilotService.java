package com.hcl.ams.AirportManagementSystem.service;

import java.util.List;

import com.hcl.ams.AirportManagementSystem.model.Pilot;

public interface PilotService {

	public abstract Pilot savePilot(Pilot pilot);

	public abstract List<Pilot> listPilot();

}
