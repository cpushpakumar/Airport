package com.hcl.ams.AirportManagementSystem.model;

public enum Gender {

	MALE, FEMALE

}
