package com.hcl.ams.AirportManagementSystem.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component("manager")
@Entity
@Table(name = "managers")
public class Manager {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "MANAGER_ID")
	private int id;

	@Column(name = "MANAGER_EMAIL", length = 20)
	private String email;

	@Column(name = "MANAGER_PASSWORD", length = 20)
	private String password;

	@Column(name = "MANAGER_FIRSTNAME", length = 20)
	private String firstName;

	@Column(name = "MANAGER_LASTNAME", length = 20)
	private String lastName;

	@Column(name = "MANAGER_AGE")
	private int age;

	@Column(name = "MANAGER_GENDER")
	@Enumerated(EnumType.STRING)
	private Gender gender;

	@Column(name = "MANAGER_CONTACTNUMBER")
	private long contactNumber;

	@Column(name = "ROLE")
	@Enumerated(EnumType.STRING)
	private Role role;

	@Column(name = "ADMIN_APPROVAL_STATUS", length = 10)
	private String approvalStatus;

	public Manager() {
		super();
	}

	public Manager(int id, String email, String password, String firstName, String lastName, int age, Gender gender,
			long contactNumber, Role role, String approvalStatus) {
		super();
		this.id = id;
		this.email = email;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.gender = gender;
		this.contactNumber = contactNumber;
		this.role = role;
		this.approvalStatus = approvalStatus;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

}
