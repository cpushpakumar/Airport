package com.hcl.ams.AirportManagementSystem.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.hcl.ams.AirportManagementSystem.appexception.ApplicationException;
import com.hcl.ams.AirportManagementSystem.model.Manager;

public interface ManagerService {

	public abstract List<Manager> getAllManagers() throws ApplicationException;

	public abstract ResponseEntity<Manager> approveManager(Manager manager);

}
