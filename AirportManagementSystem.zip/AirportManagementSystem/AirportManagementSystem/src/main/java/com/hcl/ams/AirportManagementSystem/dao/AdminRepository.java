package com.hcl.ams.AirportManagementSystem.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.ams.AirportManagementSystem.model.Admin;

public interface AdminRepository extends JpaRepository<Admin, Long> {

	public Optional<Admin> findByEmailAndPassword(String email, String password);
}
