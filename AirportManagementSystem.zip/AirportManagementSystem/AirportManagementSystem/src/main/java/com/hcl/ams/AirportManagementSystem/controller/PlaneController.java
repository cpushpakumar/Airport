package com.hcl.ams.AirportManagementSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContextException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.ams.AirportManagementSystem.model.Hangar;
import com.hcl.ams.AirportManagementSystem.model.Pilot;
import com.hcl.ams.AirportManagementSystem.model.Plane;
import com.hcl.ams.AirportManagementSystem.service.PlaneService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class PlaneController {

	@Autowired
	private PlaneService planeService;

	@PostMapping("/Plane")
	public ResponseEntity<Plane> addPlane(@RequestBody Plane plane) {
		try {
			planeService.addPlane(plane);
			return new ResponseEntity<Plane>(plane, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
		}
	}

	@GetMapping("/ListPlane")
	public ResponseEntity<List<Plane>> serachplane() {
		try {
			List<Plane> plane = planeService.listPlane();
			return new ResponseEntity<List<Plane>>(plane, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
		}
	}

	@PostMapping("/{id}/allotinghangarsandplanes")
	public ResponseEntity<Plane> approvePlane(@RequestBody Hangar hangar, @PathVariable("id") String id) {
		long _id = Long.valueOf(id);
		try {
			Plane plane = planeService.allotHangarPlanes(hangar, _id);
			return new ResponseEntity<Plane>(plane, HttpStatus.CREATED);
		} catch (Exception e) {
			throw new ApplicationContextException("Invalid Allocation");

		}

	}

	@PostMapping("/{id}/allotinghangarsandplanes/pilot")
	public ResponseEntity<Plane> approvePilot(@RequestBody Pilot pilot, @PathVariable("id") String id) {
		long _id = Long.valueOf(id);
		try {
			Plane plane = planeService.allotPilotPlanes(pilot, _id);
			return new ResponseEntity<Plane>(plane, HttpStatus.CREATED);
		} catch (Exception e) {
			throw new ApplicationContextException("Invalid Allocation");

		}

	}
}
