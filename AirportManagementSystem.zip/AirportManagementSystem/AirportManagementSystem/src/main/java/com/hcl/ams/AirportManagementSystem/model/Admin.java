package com.hcl.ams.AirportManagementSystem.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component("admin")
@Entity
@Table(name = "admins")
public class Admin {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ADMIN_ID")
	private int id;

	@Column(name = "ADMIN_EMAIL", unique = true, nullable = false, length = 50)
	private String email;

	@Column(name = "ADMIN_PASSWORD")
	private String password;

	@Column(name = "ADMIN_FIRSTNAME")
	private String firstName;

	@Column(name = "ADMIN_LASTNAME")
	private String lastName;

	@Column(name = "ADMIN_AGE")
	private int age;

	@Column(name = "ADMIN_GENDER")
	@Enumerated(EnumType.STRING)
	private Gender gender;

	@Column(name = "ADMIN_CONTACTNUMBER")
	private long contactNumber;

	@Column(name = "ROLE")
	@Enumerated(EnumType.STRING)
	private Role role;

	public Admin() {
		super();
	}

	public Admin(int id, String email, String password, String firstName, String lastName, int age, Gender gender,
			long contactNumber, Role role) {
		super();
		this.id = id;
		this.email = email;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.gender = gender;
		this.contactNumber = contactNumber;
		this.role = role;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

}
