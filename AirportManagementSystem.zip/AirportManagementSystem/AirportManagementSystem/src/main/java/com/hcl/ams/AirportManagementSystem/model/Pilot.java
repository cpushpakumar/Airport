package com.hcl.ams.AirportManagementSystem.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component("pilot")
@Entity
@Table(name = "pilots")
public class Pilot {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PILOT_ID")
	private int pilotId;

	@Column(name = "PILOT_NAME", length = 20, unique = true)
	private String pilotName;

	@Column(name = "PILOT_LOCATION", length = 10)
	private String pilotLocation;

	private int planeId;

	public Pilot() {
		super();
	}

	public int getPilotId() {
		return pilotId;
	}

	public void setPilotId(int pilotId) {
		this.pilotId = pilotId;
	}

	public String getPilotName() {
		return pilotName;
	}

	public void setPilotName(String pilotName) {
		this.pilotName = pilotName;
	}

	public String getPilotLocation() {
		return pilotLocation;
	}

	public void setPilotLocation(String pilotLocation) {
		this.pilotLocation = pilotLocation;
	}

	public int getPlaneId() {
		return planeId;
	}

	public void setPlaneId(int planeId) {
		this.planeId = planeId;
	}

	public Pilot(int pilotId, String pilotName, String pilotLocation, int planeId) {
		super();
		this.pilotId = pilotId;
		this.pilotName = pilotName;
		this.pilotLocation = pilotLocation;
		this.planeId = planeId;
	}

}
