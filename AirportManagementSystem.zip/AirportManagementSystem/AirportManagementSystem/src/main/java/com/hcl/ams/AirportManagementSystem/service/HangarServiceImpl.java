package com.hcl.ams.AirportManagementSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.ams.AirportManagementSystem.dao.HangarRepository;
import com.hcl.ams.AirportManagementSystem.model.Hangar;

@Transactional
@Service
public class HangarServiceImpl implements HangarService {

	@Autowired
	private HangarRepository hangarRepository;

	@Override
	public Hangar addHanger(Hangar hangar) {

		return hangarRepository.save(hangar);
	}

	@Override
	public List<Hangar> listHangar() {

		return hangarRepository.findAll();
	}

}
