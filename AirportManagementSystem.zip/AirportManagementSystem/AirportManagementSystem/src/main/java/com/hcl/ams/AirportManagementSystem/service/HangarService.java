package com.hcl.ams.AirportManagementSystem.service;

import java.util.List;

import com.hcl.ams.AirportManagementSystem.model.Hangar;

public interface HangarService {

	public abstract Hangar addHanger(Hangar hangar);

	public abstract List<Hangar> listHangar();

}
