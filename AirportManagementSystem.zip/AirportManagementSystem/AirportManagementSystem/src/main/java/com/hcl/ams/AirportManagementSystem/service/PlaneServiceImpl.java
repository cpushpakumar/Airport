package com.hcl.ams.AirportManagementSystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContextException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.ams.AirportManagementSystem.dao.HangarRepository;
import com.hcl.ams.AirportManagementSystem.dao.PilotRepository;
import com.hcl.ams.AirportManagementSystem.dao.PlaneRepository;
import com.hcl.ams.AirportManagementSystem.model.Hangar;
import com.hcl.ams.AirportManagementSystem.model.Pilot;
import com.hcl.ams.AirportManagementSystem.model.Plane;

@Transactional
@Service
public class PlaneServiceImpl implements PlaneService {

	@Autowired
	private PlaneRepository planeRepository;

	@Autowired
	private HangarRepository hangarRepository;

	@Autowired
	private PilotRepository pilotRepository;

	@Override
	public Plane addPlane(Plane plane) {

		return planeRepository.save(plane);
	}

	@Override
	public List<Plane> listPlane() {
		return planeRepository.findAll();
	}

	@Override
	public Plane allotHangarPlanes(Hangar hangar, long _id) {
		Plane _plane = new Plane();
		try {
			Optional<Plane> plane = planeRepository.findById(_id);
			if (plane.isPresent()) {
				_plane = plane.get();

				_plane.setHangarId(hangar.getHangarId());

			} else {
				throw new ApplicationContextException("Invalid Allotment");
			}
		} catch (Exception e) {
			throw new ApplicationContextException("Invalid");
		}
		hangar.setPlaneId((int) _id);
		hangarRepository.save(hangar);
		return _plane;
	}

	@Override
	public Plane allotPilotPlanes(Pilot pilot, long _id) {

		Plane _plane = new Plane();
		try {
			Optional<Plane> plane = planeRepository.findById(_id);
			if (plane.isPresent()) {
				_plane = plane.get();

				_plane.setPilotId(pilot.getPilotId());

			} else {
				throw new ApplicationContextException("Invalid Allotment");
			}
		} catch (Exception e) {
			throw new ApplicationContextException("Invalid");
		}
		pilot.setPlaneId((int) _id);
		pilotRepository.save(pilot);
		return _plane;

	}

}
