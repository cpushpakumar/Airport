package com.hcl.ams.AirportManagementSystem.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.ams.AirportManagementSystem.dao.PilotRepository;
import com.hcl.ams.AirportManagementSystem.model.Pilot;

@Service
public class PilotServiceImpl implements PilotService {

	@Autowired
	private PilotRepository pilotRepository;

	@Override
	public Pilot savePilot(Pilot pilot) {

		return pilotRepository.save(pilot);
	}

	@Override
	public List<Pilot> listPilot() {
		List<Pilot> pilot = new ArrayList<>();
		pilot = pilotRepository.findAll();

		return pilot;
	}
}
