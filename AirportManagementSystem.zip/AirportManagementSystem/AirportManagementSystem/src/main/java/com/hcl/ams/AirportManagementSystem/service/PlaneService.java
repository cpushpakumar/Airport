package com.hcl.ams.AirportManagementSystem.service;

import java.util.List;

import com.hcl.ams.AirportManagementSystem.model.Hangar;
import com.hcl.ams.AirportManagementSystem.model.Pilot;
import com.hcl.ams.AirportManagementSystem.model.Plane;

public interface PlaneService {

	public abstract Plane addPlane(Plane plane);

	public abstract List<Plane> listPlane();

	Plane allotHangarPlanes(Hangar hangar, long _id);

	Plane allotPilotPlanes(Pilot pilot, long _id);

}
