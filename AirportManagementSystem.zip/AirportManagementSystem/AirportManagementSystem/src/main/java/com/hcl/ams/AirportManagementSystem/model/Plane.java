package com.hcl.ams.AirportManagementSystem.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.springframework.stereotype.Component;

@Component("plane")
@Entity
@Table(name = "planes")
public class Plane implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PLANE_ID")
	private long planeId;

	@Column(name = "PLANE_NAME", length = 10, unique = true)
	private String planeName;

	private int hangarId;

	private int pilotId;

	public Plane() {
		super();
	}

	public Plane(long planeId, String planeName, int hangarId, int pilotId) {
		super();
		this.planeId = planeId;
		this.planeName = planeName;
		this.hangarId = hangarId;
		this.pilotId = pilotId;
	}

	public long getPlaneId() {
		return planeId;
	}

	public void setPlaneId(long planeId) {
		this.planeId = planeId;
	}

	public String getPlaneName() {
		return planeName;
	}

	public void setPlaneName(String planeName) {
		this.planeName = planeName;
	}

	public int getHangarId() {
		return hangarId;
	}

	public void setHangarId(int hangarId) {
		this.hangarId = hangarId;
	}

	public int getPilotId() {
		return pilotId;
	}

	public void setPilotId(int pilotId) {
		this.pilotId = pilotId;
	}

}