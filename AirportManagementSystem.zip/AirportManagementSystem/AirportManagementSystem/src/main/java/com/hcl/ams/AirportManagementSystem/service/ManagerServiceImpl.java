package com.hcl.ams.AirportManagementSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.hcl.ams.AirportManagementSystem.appexception.ApplicationException;
import com.hcl.ams.AirportManagementSystem.dao.ManagerRepository;
import com.hcl.ams.AirportManagementSystem.model.Manager;

@Service
public class ManagerServiceImpl implements ManagerService {

	@Autowired
	private ManagerRepository managerRepository;

	@Override
	public List<Manager> getAllManagers() throws ApplicationException {
		try {
			List<Manager> managers = managerRepository.findAll();
			if (managers.isEmpty()) {
				throw new ApplicationException("EmptyList");
			} else {
				return managers;
			}
		} catch (Exception e) {
			throw new ApplicationException("EmptyList");
		}
	}

	@Override
	public ResponseEntity<Manager> approveManager(Manager manager) {
		try {
			Manager _manager = managerRepository.save(manager);
			return new ResponseEntity<Manager>(_manager, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
}
