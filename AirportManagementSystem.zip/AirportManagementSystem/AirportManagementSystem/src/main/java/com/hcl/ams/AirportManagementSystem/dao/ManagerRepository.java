package com.hcl.ams.AirportManagementSystem.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.ams.AirportManagementSystem.model.Manager;

public interface ManagerRepository extends JpaRepository<Manager, Long> {

	public Optional<Manager> findByEmailAndPassword(String email, String password);

}
