package com.hcl.ams.AirportManagementSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.ams.AirportManagementSystem.appexception.ApplicationException;
import com.hcl.ams.AirportManagementSystem.dao.HangarRepository;
import com.hcl.ams.AirportManagementSystem.model.Hangar;
import com.hcl.ams.AirportManagementSystem.service.HangarService;

import lombok.extern.log4j.Log4j;
import lombok.extern.slf4j.Slf4j;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@Slf4j
@Log4j
public class HangarController {

	@Autowired
	private HangarService hangarService;

	@Autowired
	private HangarRepository hangarRepository;

	@PostMapping("/hangerdetails")
	public ResponseEntity<Hangar> addHanger(@RequestBody Hangar hangar) throws ApplicationException {
		try {
			//log.info("Inside the sayHello() in controller");
			Hangar _hangar = hangarRepository.save(hangar);
			return new ResponseEntity<Hangar>(_hangar, HttpStatus.CREATED);
		} catch (DataIntegrityViolationException e) {
			return new ResponseEntity<>(null, HttpStatus.ALREADY_REPORTED);
		} catch (Exception e) {
			throw new ApplicationException("Not Acceptable");
		}
	}

	@GetMapping("/Listhangars")
	public ResponseEntity<List<Hangar>> serachHangar() {
		try {
			List<Hangar> hangar = hangarService.listHangar();
			return new ResponseEntity<List<Hangar>>(hangar, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
		}
	}

}
