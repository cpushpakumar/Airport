package com.hcl.ams.AirportManagementSystem.test;



import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages="com.hcl.ams.AirportManagementSystem")
public class AnotherTest {

}