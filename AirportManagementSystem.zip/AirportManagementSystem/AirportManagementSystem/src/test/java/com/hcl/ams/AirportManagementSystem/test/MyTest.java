package com.hcl.ams.AirportManagementSystem.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.hcl.ams.AirportManagementSystem.dao.HangarRepository;
import com.hcl.ams.AirportManagementSystem.model.Hangar;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = { AnotherTest.class })

public class MyTest {

	@Autowired
	private HangarRepository hangarRepo;

	@Test
	public void hangarSave() {
		Hangar han = new Hangar(300, "420D", 101);
		hangarRepo.save(han);
	}

	@Test
	public void sampleTest2() {

	}

}
